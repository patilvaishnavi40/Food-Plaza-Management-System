package com.foodplaza.pojo;

public class Cart
{
	private int cartId ,foodQty ,foodId;
	private String foodName , customerEmailId;
	private double foodPrice;
	
	public int getCartId() 
	{
		return cartId;
	}
	
	public void setCartId(int cartId) 
	{
		this.cartId = cartId;
	}
	
	public int getFoodQty() 
	{
		return foodQty;
	}
	
	public void setFoodQty(int foodQty) 
	{
		this.foodQty = foodQty;
	}
	
	public int getFoodId() 
	{
		return foodId;
	}
	
	public void setFoodId(int foodId) 
	{
		this.foodId = foodId;
	}
	
	public String getFoodName() 
	{
		return foodName;
	}
	
	public void setFoodName(String foodName)
	{
		this.foodName = foodName;
	}
	
	public String getCustomerEmailId() 
	{
		return customerEmailId;
	}
	
	public void setCustomerEmailId(String customerEmailId)
	{
		this.customerEmailId = customerEmailId;
	}
	
	public double getFoodPrice() 
	{
		return foodPrice;
	}
	
	public void setFoodPrice(double foodPrice) 
	{
		this.foodPrice = foodPrice;
	}
	
	
}